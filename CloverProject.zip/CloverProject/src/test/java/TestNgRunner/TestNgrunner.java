package TestNgRunner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
		features = "Feature",
		glue = "StepDefinition"
		//tags = "@Search"
		
)


public class TestNgrunner extends AbstractTestNGCucumberTests{

}
