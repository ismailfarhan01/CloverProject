package PageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GoogleSearchPage {
	public WebDriver driver;
	public GoogleSearchPage(WebDriver driver) {
		this.driver = driver;
		
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//input[@class='gLFyf gsfi']" )
	
	  public WebElement SearchBox;
	 
	 public void getSearchBox() { 
		 SearchBox.sendKeys("Clover");

}
	
	 @FindBy(xpath="//input[@class='gLFyf gsfi']" )
		
	  public WebElement SearchButton;
	 
	 public void getSearchButton() { 
		 SearchButton.sendKeys(Keys.ENTER);
	 
	 }
	 
	 
	 @FindBy(xpath="//span[contains(text(),'POS System & Credit Card Readers by Clover')]" )
		
	  public WebElement CloverLink;
	 
	 public void getCloverLink() { 
		 CloverLink.click();;
		
	 
	 }
	 
}
