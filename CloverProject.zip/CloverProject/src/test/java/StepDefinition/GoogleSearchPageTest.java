package StepDefinition;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import Common.Base;
import PageObjectModel.GoogleSearchPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GoogleSearchPageTest extends Base {
	

	GoogleSearchPage gp;//create an instance variable
	

	@Given("^User is on the Google page$")
	public void user_is_on_the_Google_page() {
		
		getDriver();
		gp = PageFactory.initElements(driver, GoogleSearchPage.class);
		
	}

	@When("^User write Clover on the Search box$")
	public void user_write_Clover_on_the_Search_box() {
		gp.getSearchBox();
	}

	@When("^Click the search button$")
	public void click_the_search_button() {
		gp.getSearchButton();
	}

	@When("^User should able to see the clover site hyperlink and click on it$")
	public void user_should_able_to_see_the_clover_site_hyperlink() {
		gp.getCloverLink();
	}
	
	@Then("^User should be on the Clover's Homepage\\.$")
	public void user_should_be_on_the_Clover_s_Homepage() {
	
	
	}


}
